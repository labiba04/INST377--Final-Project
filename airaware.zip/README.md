# AirAware 🌿

A real-time air quality dashboard that uses OpenWeatherMap's APIs to help users make healthy, informed decisions about outdoor air.

## Target Browsers
- Chrome, Safari, Firefox (Mobile + Desktop)
- iOS Safari
- Android Chrome

## Developer Manual
See `docs/developer_manual.md`.